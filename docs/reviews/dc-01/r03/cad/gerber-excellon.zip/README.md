# Unreleased fabrication candidate

These are actual native KiCad10.0.6 Gerber X2 and Excellon outputs from the hash-bound carrier. ERC/DRC and schematic parity passed on the source CAD. Physical electrical/thermal qualification, complete AVL and assembly review remain open. **Do not submit these files for manufacture as an approved design.**

Two copper layers; nominal board54x46x1.6mm. Source assumptions: copper35um each face, FR-4, no controlled impedance; fabricator stackup and process have not been approved. Separate plated/nonplated drills are included. No stencil is released because solder-paste and assembly-process definitions are open.
